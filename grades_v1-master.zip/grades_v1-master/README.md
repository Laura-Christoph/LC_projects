# Grades_v1

This is just me playing around with my brothers grades... 

## What is it about?
Well... I am trying out some functions. Thats it actually

## What did I use?

- Only modules that are already integrated in the python library. Yes, I am that lazy.

## License
MIT License....

## Project status
It is clearly not finished.
