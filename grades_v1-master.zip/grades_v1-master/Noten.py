#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun  9 16:37:35 2022

@author: laurachristoph
"""

import time
from typing import List, Tuple
import re
import random
import csv

class Subject:
    """
    Subject elements contain subject name and grades
    """
    def __init__(self,grades) -> None:
        self.subject = str(grades[0])
        self.grades_first_sem = grades[1:]
        
        unedited_grades = self.grades_first_sem
        grades_list = self.grades_first_sem
        #grades_list = []
        #for list in unedited_grades:
           # a = ",".join(list)
           # b=a.split(",")
            
           # grades_list.append(b)
        zip_iterator = zip(self.subject,grades_list)
        
        self.grades_dict = dict(zip_iterator)
              

     
        
        
    def pretty_display(a) -> str:
        """
        This function returns a big string like this:
            subject1: grade1,grade2,grade3; subject2: grade1,... 
        """
        for element in a:
            ' '.join(element).split()
            
            if type(element) == type('str'):
                print(element, ": ")
            else:
                print(element)
            
            
        
        
     
   
    def average_subject(self) -> int:
        """
        This function returns the mean of the grades of a subject of choice:
            average_subject("MA")
        """ 
        subject = input("Subject: ")
        for sub in self.subjects:
            if str(sub)==str(subject):
                grades = self.grades_dict(sub)
                average = sum(grades)/len(grades)
                return average
            else:
                f'This subject does not exist in the csv file.'
                
            
        
        
        
        pass
        
        
    def rang_of_the_grades(self) -> dict:
        """
        This function returns a sorted dictionary with the means of the grades.
        """
        mean_grades_dict={}
        for element in self.subject:
            grades = self.grades_dict[element]
            mean = sum(grades)/len(grades)
            mean_grades_dict[element]=mean
            
        rang = {k: v for k, v in sorted(mean_grades_dict.items(), key=lambda item: item[1])}
        return rang
    
    
    
    
    
def make_grades_objects(filename) -> list[list]:
    with open(filename,"r") as subs:
        subs_1 = csv.reader(subs, delimiter=";")
        next(subs_1)
        row_list = [row for row in subs_1]
        grades_list = []
        
            
        
               
            #grades_list.append(Subject(row))
    return row_list
  
b = make_grades_objects("Noten.csv") 
bb = [Subject.pretty_display(i) for i in b]
print(bb)

a = Subject.average_subject()

